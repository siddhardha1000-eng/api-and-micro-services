package com.siddhardha.apiandmicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiAndMicroServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
