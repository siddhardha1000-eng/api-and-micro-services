package com.siddhardha.apiandmicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiAndMicroServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiAndMicroServicesApplication.class, args);
	}

}
